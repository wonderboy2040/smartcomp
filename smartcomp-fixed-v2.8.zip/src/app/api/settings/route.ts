import { NextResponse } from 'next/server'
import { testConnection, getConfiguredUrlPreview } from '@/lib/sheets-client'

// GET - connection status + masked URL preview (so user can verify the URL format)
export async function GET() {
  const urlInfo = getConfiguredUrlPreview()
  return NextResponse.json({
    message: 'Google Sheets sync is configured via APPS_SCRIPT_URL environment variable.',
    urlPreview: urlInfo.urlPreview,
    urlConfigured: urlInfo.configured,
    urlEndsWithExec: urlInfo.endsWithExec,
  })
}

// POST - test connection
export async function POST() {
  const result = await testConnection()
  return NextResponse.json(result)
}
